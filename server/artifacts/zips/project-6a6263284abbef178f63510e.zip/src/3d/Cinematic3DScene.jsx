import { useRef, useMemo, createRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Float, Stars, Environment } from '@react-three/drei'
import { EffectComposer, Bloom } from '@react-three/postprocessing'
import * as THREE from 'three'

// ─── Custom 3D Object: FloatingSphere ──────────────────────────────────────

function FloatingSphere() {
  const sphereRef = useRef()
  const ring1Ref  = useRef()
  const ring2Ref  = useRef()

  useFrame(({ clock }) => {
    const t = clock.elapsedTime
    sphereRef.current.position.y = Math.sin(t * 0.78) * 0.28
    ring1Ref.current.rotation.z  = t * 0.42
    ring2Ref.current.rotation.x  = t * 0.3
    ring2Ref.current.rotation.z  = -t * 0.18
  })

  return (
    <group>
      <mesh ref={sphereRef}>
        <sphereGeometry args={[1.25, 64, 64]} />
        <meshPhysicalMaterial
          color="#3d5eff"
          emissive="#3d5eff"
          emissiveIntensity={0.18}
          metalness={0.28}
          roughness={0.1}
          envMapIntensity={1.6}
        />
      </mesh>
      <mesh ref={ring1Ref} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.72, 1.78, 64]} />
        <meshBasicMaterial color="#00d4ff" transparent opacity={0.65} side={THREE.DoubleSide} />
      </mesh>
      <mesh ref={ring2Ref} rotation={[Math.PI / 3, 0.5, 0]}>
        <ringGeometry args={[2.05, 2.09, 64]} />
        <meshBasicMaterial color="#bf5fff" transparent opacity={0.38} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

// ─── Ambient particle field ───────────────────────────────────────────────────
function AmbientParticles({ count = 700 }) {
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      arr[i * 3]     = (Math.random() - 0.5) * 16
      arr[i * 3 + 1] = (Math.random() - 0.5) * 16
      arr[i * 3 + 2] = (Math.random() - 0.5) * 16
    }
    return arr
  }, [count])

  const ref = useRef()
  useFrame(({ clock }) => {
    ref.current.rotation.y = clock.elapsedTime * 0.035
    ref.current.rotation.x = clock.elapsedTime * 0.018
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#3d5eff"
        size={0.028}
        transparent
        opacity={0.65}
        sizeAttenuation
      />
    </points>
  )
}

// ─── Scene ────────────────────────────────────────────────────────────────────
export default function Cinematic3DScene() {
  return (
    <>
      <color attach="background" args={['#0a0a14']} />

      {/* Lighting rig */}
      <ambientLight intensity={0.22} />
      <pointLight position={[8, 8, 8]}   intensity={3.2} color="#3d5eff" decay={2} />
      <pointLight position={[-8, -5, -6]} intensity={1.8} color="#bf5fff" decay={2} />
      <spotLight
        position={[0, 14, 5]}
        angle={0.38}
        penumbra={1}
        intensity={4.5}
        color="#00d4ff"
        castShadow
      />

      {/* Deep-space starfield */}
      <Stars radius={90} depth={60} count={2200} factor={3.8} fade speed={0.7} />

      {/* Main subject — floats gently */}
      <Float speed={1.75} rotationIntensity={0.38} floatIntensity={1.15}>
        <FloatingSphere />
      </Float>

      {/* Background particles */}
      <AmbientParticles count={700} />

      {/* Post-processing */}
      <EffectComposer>
        <Bloom
          luminanceThreshold={0.48}
          luminanceSmoothing={0.82}
          intensity={1.45}
        />
      </EffectComposer>
    </>
  )
}