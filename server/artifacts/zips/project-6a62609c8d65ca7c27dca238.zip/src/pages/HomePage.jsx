import HeroSection from '../components/sections/HeroSection';
import SampleSection from '../components/sections/SampleSection';
export default function HomePage() { return <div><HeroSection /><SampleSection /></div>; }