import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { motion } from 'framer-motion'
import Cinematic3DScene from '../3d/Cinematic3DScene'

export default function Hero() {
  return (
    <section
      className="relative min-h-screen grid lg:grid-cols-2 overflow-hidden"
      style={{ background: '#0a0a14' }}
    >
      {/* ── Left: content column ───────────────────────────────────────── */}
      <div className="flex flex-col justify-center px-10 lg:px-20 py-36 z-10">
        <motion.div
          className="mb-8 inline-flex items-center gap-2 self-start px-4 py-1.5 rounded-full text-sm font-medium"
          style={{ background: '#3d5eff22', border: '1px solid #3d5eff55', color: '#00d4ff' }}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#00d4ff' }} />
          Startup Technology
        </motion.div>

        <motion.h1
          className="font-bold leading-tight mb-6"
          style={{ fontSize: 'clamp(2.8rem, 5vw, 5rem)', color: '#f0f0ff' }}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        >
          Welcome to Create
        </motion.h1>

        <motion.p
          className="text-lg lg:text-xl mb-10 max-w-xl"
          style={{ color: '#f0f0ff99' }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.22 }}
        >
          The Future of Create
        </motion.p>

        <motion.div
          className="flex flex-wrap gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.36 }}
        >
          <button
            className="px-8 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:opacity-90 hover:scale-[1.03]"
            style={{ background: '#3d5eff', color: '#fff' }}
          >
            Get Started
          </button>
          <button
            className="px-8 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:opacity-80"
            style={{ border: '1px solid #f0f0ff30', color: '#f0f0ff99' }}
          >
            Learn More
          </button>
        </motion.div>
      </div>

      {/* ── Right: 3D canvas ────────────────────────────────────────────── */}
      <div className="relative min-h-[55vh] lg:min-h-screen">
        <div className="absolute inset-0">
          <Canvas camera={{ position: [0, 0, 5.5], fov: 58 }} dpr={[1, 2]}>
            <Suspense fallback={null}>
              <Cinematic3DScene />
            </Suspense>
          </Canvas>
        </div>
        {/* Fade to bg on left edge */}
        <div
          className="absolute inset-y-0 left-0 w-24 pointer-events-none"
          style={{ background: 'linear-gradient(to right, #0a0a14, transparent)' }}
        />
      </div>

      {/* Bottom fade */}
      <div
        className="absolute bottom-0 inset-x-0 h-32 pointer-events-none z-10"
        style={{ background: 'linear-gradient(to top, #0a0a14, transparent)' }}
      />
    </section>
  )
}